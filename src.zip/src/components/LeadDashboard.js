import React, { useState, useEffect } from "react";
import LeadSidebar from "./LeadSidebar";
import Home from "./Home";
import LeadPage from "./LeadPage";
import "./LeadDashboard.css";

const LeadDashboard = () => {
  document.title = "Dashboard | Lead";

  // Retrieve the active component from localStorage, default to "home"
  const [activeComponent, setActiveComponent] = useState(() => {
    return localStorage.getItem("leadActiveComponent") || "home";
  });

  // Save the active component to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("leadActiveComponent", activeComponent);
  }, [activeComponent]);

  const renderContent = () => {
    switch (activeComponent) {
      case "home":
        return <Home />;
      case "view-timesheet":
        return <LeadPage />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="lead-dashboard">
      <LeadSidebar setActiveComponent={setActiveComponent} />
      <div className="lead-content">{renderContent()}</div>
    </div>
  );
};

export default LeadDashboard;
