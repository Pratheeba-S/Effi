import React from "react";
import { FaHome, FaUsers, FaSignOutAlt } from "react-icons/fa";
import "./HRSidebar.css"; // Use the HRSidebar.css for styling

const HRSidebar = ({ setActiveComponent }) => {
  const handleLogout = () => {
    // Clear the stored active component when logging out
    localStorage.removeItem("hrActiveComponent");
    localStorage.removeItem("token");
    localStorage.removeItem("empId");
    window.location.href = "/login";
  };

  return (
    <div className="hr-sidebar">
      <h2>HR Dashboard</h2>
      <ul>
        <li onClick={() => setActiveComponent("home")}>
          <FaHome className="icon" /> Dashboard
        </li>
        <li onClick={() => setActiveComponent("employee-details")}>
          <FaUsers className="icon" /> Employee Details
        </li>
        <li onClick={handleLogout}>
          <FaSignOutAlt className="icon" /> Logout
        </li>
      </ul>
    </div>
  );
};

export default HRSidebar;
