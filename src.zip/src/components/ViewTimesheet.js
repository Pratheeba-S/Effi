import React, { useState, useEffect } from "react";
import timesheetService from "../services/timesheetService";
import "./ViewTimesheet.css";
import { useAuth } from "../context/AuthContext";

function ViewTimesheet() {
  document.title = "ViewTimesheet | Employee";
  const [timesheets, setTimesheets] = useState([]);
  const [filteredTimesheets, setFilteredTimesheets] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const { empId } = useAuth();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  useEffect(() => {
    console.log("Fetching timesheets for empId:", empId);
    loadTimesheets();
  }, [empId]);

  const loadTimesheets = async () => {
    try {
      const response = await timesheetService.getTimesheets();
      console.log("Timesheets fetched:", response.data);
      const employeeTimesheets = response.data.filter(
        (t) => t.emp_id === empId
      );
      console.log("Filtered timesheets:", employeeTimesheets);
      setTimesheets(employeeTimesheets);
      setFilteredTimesheets(employeeTimesheets);
    } catch (error) {
      console.error("Error loading timesheets:", error);
    }
  };

  const handleDateChange = (e) => {
    const inputDate = e.target.value;
    if (inputDate) {
      const date = new Date(inputDate);
      if (!isNaN(date.getTime())) {
        const formattedDate = date.toISOString().split("T")[0];
        setSelectedDate(formattedDate);

        const filtered = timesheets.filter((t) => t.date === formattedDate);
        setFilteredTimesheets(filtered);
      } else {
        console.error("Invalid date value");
        setFilteredTimesheets([]);
      }
    } else {
      handleShowAll();
    }
  };

  const handleShowAll = () => {
    setSelectedDate(null);
    setFilteredTimesheets(timesheets);
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return `${date.toISOString().split("T")[0]} ${
      date.toTimeString().split(" ")[0]
    }`;
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const renderTimesheetDetails = () => {
    if (!filteredTimesheets.length) return <p>No entries available</p>;

    // Pagination logic
    const indexOfLast = currentPage * itemsPerPage;
    const indexOfFirst = indexOfLast - itemsPerPage;
    const currentTimesheets = filteredTimesheets.slice(
      indexOfFirst,
      indexOfLast
    );

    return (
      <div className="timesheet-detailss">
        <h3>
          {selectedDate
            ? `Timesheet Details for ${selectedDate}`
            : "All Timesheet Entries"}
        </h3>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Employee Name</th>
              <th>Project Name</th>
              <th>Start Time</th>
              <th>End Time</th>
              <th>Total Hours</th>
              <th>Timestamp</th>
              <th>Comments</th>
              <th>Lead Approval</th>
              <th>Manager Approval</th>
            </tr>
          </thead>
          <tbody>
            {currentTimesheets.map((entry, idx) => (
              <tr key={idx}>
                <td>{entry.date}</td>
                <td>{entry.emp_name}</td>
                <td>{entry.project_name}</td>
                <td>{entry.start_time}</td>
                <td>{entry.end_time}</td>
                <td>{entry.total_hours}</td>
                <td>{formatTimestamp(entry.timestamp)}</td>
                <td>{entry.comments}</td>
                <td>{entry.lead_approval}</td>
                <td>{entry.manager_approval}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* Pagination Controls */}
        <div className="pagination-controls">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            &lt;
          </button>
          <span>
            Page {currentPage} of{" "}
            {Math.ceil(filteredTimesheets.length / itemsPerPage)}
          </span>
          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={
              currentPage ===
              Math.ceil(filteredTimesheets.length / itemsPerPage)
            }
          >
            &gt;
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="view-timesheet-container">
      <h2>Timesheet Entries</h2>
      <div className="date-selector">
        <input type="date" onChange={handleDateChange} />
        <button onClick={handleShowAll}>Show All</button>
      </div>
      {renderTimesheetDetails()}
    </div>
  );
}

export default ViewTimesheet;
