import React from "react";
import { useAuth } from "../context/AuthContext";
import "./HRHome.css"; // Make sure to create this file for styling

const HRHome = () => {
  const { empId } = useAuth();

  return (
    <div className="home-container">
      <div className="home-content">
        <h1>Welcome, HR</h1>
        <p>User ID: {empId}</p>
        <p>We're glad to have you here!</p>
      </div>
    </div>
  );
};

export default HRHome;
