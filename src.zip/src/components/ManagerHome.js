import React from "react";
import styled from "styled-components";
import { useAuth } from "../context/AuthContext";

// Styled components
const Container = styled.div`
  padding: 25px;
  background-color: #021526;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  margin-left: 0; /* Adjust this value to control the left margin */
`;

const Content = styled.div`
  text-align: center;
  width: 400px;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin: auto;
  position: relative;
  top: 50%;
  transform: translateY(-50%);
`;

const Heading = styled.h2`
  color: #201e43;
  font-size: 2.5em;
  margin-bottom: 20px;
`;

const Paragraph = styled.p`
  color: #134b70;
  font-size: 1.2em;
  margin: 10px 0;
`;

const ManagerHome = () => {
  const { empId } = useAuth();

  return (
    <Container>
      <Content>
        <Heading>Welcome, Manager</Heading>
        <Paragraph>User ID: {empId}</Paragraph>
        <Paragraph>We're glad to have you here!</Paragraph>
      </Content>
    </Container>
  );
};

export default ManagerHome;
