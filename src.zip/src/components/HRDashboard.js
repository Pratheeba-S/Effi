import React, { useState, useEffect } from "react";
import HRSidebar from "./HRSidebar"; // Make sure to create this file
import HRHome from "./HRHome"; // Assuming this component can be reused or you can create a separate one for HR
import EmployeeDetails from "./EmployeeDetails"; // Import the EmployeeDetails component
import "./HRDashboard.css"; // Make sure to create this file for HR dashboard styling

const HRDashboard = () => {
  document.title = "Dashboard | HR"; // Set the document title

  // Retrieve the active component from localStorage, default to "home"
  const [activeComponent, setActiveComponent] = useState(() => {
    return localStorage.getItem("hrActiveComponent") || "home";
  });

  // Save the active component to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("hrActiveComponent", activeComponent);
  }, [activeComponent]);

  const renderContent = () => {
    switch (activeComponent) {
      case "home":
        return <HRHome />; // You might want to create an HR-specific Home component
      case "employee-details":
        return <EmployeeDetails />; // Ensure this component is implemented
      default:
        return <HRHome />; // Default fallback
    }
  };

  return (
    <div className="hr-dashboard">
      <HRSidebar setActiveComponent={setActiveComponent} />
      <div className="hr-content">{renderContent()}</div>
    </div>
  );
};

export default HRDashboard;
