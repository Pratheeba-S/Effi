import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom"; // Import useNavigate
import axios from "axios";
import "./EmployeeTimesheetDetails.css";

const EmployeeTimesheetDetails = () => {
  document.title = "Employee Details | HR";
  const { empId } = useParams();
  const [timesheets, setTimesheets] = useState([]);
  const [filteredTimesheets, setFilteredTimesheets] = useState([]);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    const fetchTimesheets = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get(`/api/hr-timesheets/${empId}`, {
          params: {
            month: currentMonth + 1, // API expects 1-12 for month
            year: currentYear,
          },
        });
        const data = response.data;
        setTimesheets(data);
        filterTimesheets(data);
      } catch (error) {
        setError("Error fetching timesheets. Please try again later.");
        console.error("Error fetching timesheets:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTimesheets();
  }, [empId, currentMonth, currentYear]);

  useEffect(() => {
    if (timesheets.length > 0) {
      filterTimesheets(timesheets);
    }
  }, [currentMonth, currentYear, timesheets]);

  const filterTimesheets = (data) => {
    const filtered = data.filter((timesheet) => {
      const date = new Date(timesheet.date);
      return (
        date.getMonth() === currentMonth && date.getFullYear() === currentYear
      );
    });
    setFilteredTimesheets(filtered);
  };

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((prevYear) => prevYear - 1);
    } else {
      setCurrentMonth((prevMonth) => prevMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((prevYear) => prevYear + 1);
    } else {
      setCurrentMonth((prevMonth) => prevMonth + 1);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("default", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
  };

  // Function to calculate working days, leave days, and total salary
  const calculateDaysAndSalary = () => {
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const workingDays = [...Array(daysInMonth).keys()]
      .map((day) => new Date(currentYear, currentMonth, day + 1))
      .filter((date) => date.getDay() !== 0).length; // Remove Sundays

    const uniqueDaysWithTimesheets = new Set(
      filteredTimesheets.map(
        (timesheet) => new Date(timesheet.date).toISOString().split("T")[0]
      )
    );

    const isCurrentMonth =
      currentMonth === new Date().getMonth() &&
      currentYear === new Date().getFullYear();

    const leaveDays = isCurrentMonth
      ? new Date().getDate() - uniqueDaysWithTimesheets.size
      : workingDays - uniqueDaysWithTimesheets.size;

    // Calculate total working hours and salary
    const totalHours = filteredTimesheets.reduce(
      (acc, timesheet) => acc + parseFloat(timesheet.total_hours),
      0
    );
    const salary = totalHours * 200; // 200 rupees per hour

    return { workingDays, leaveDays, salary };
  };

  const { workingDays, leaveDays, salary } = calculateDaysAndSalary();

  return (
    <div className="timesheet-details-container">
      <h2>Timesheet Details for Employee {empId} </h2>
      <div className="month-navigationn">
        <button
          className="previous-month-button"
          onClick={handlePrevMonth}
          disabled={loading}
        >
          Previous
        </button>
        <span>
          {new Date(currentYear, currentMonth).toLocaleString("default", {
            month: "long",
          })}{" "}
          {currentYear}
        </span>
        <button
          className="next-month-button"
          onClick={handleNextMonth}
          disabled={loading}
        >
          Next
        </button>
      </div>
      <div className="days-info">
        <span className="working-days">Working Days: {workingDays}</span>
        <span className="salary-info">
          <b>Salary for this month: ₹{salary.toFixed(2)}</b>
        </span>
        <span className="leave-days">Leave Days: {leaveDays}</span>
      </div>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p className="error-message">{error}</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Start Time</th>
              <th>End Time</th>
              <th>Total Hours</th>
            </tr>
          </thead>
          <tbody>
            {filteredTimesheets.length > 0 ? (
              filteredTimesheets.map((timesheet) => (
                <tr key={timesheet.id}>
                  <td>{formatDate(timesheet.date)}</td>
                  <td>{timesheet.start_time}</td>
                  <td>{timesheet.end_time}</td>
                  <td>{timesheet.total_hours}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No timesheets available for this month.</td>
              </tr>
            )}
          </tbody>
        </table>
      )}
      {/* Back Button */}
      <div className="back-button-container">
        <button onClick={() => navigate(-1)} className="back-button">
          Back
        </button>
      </div>
    </div>
  );
};

export default EmployeeTimesheetDetails;
