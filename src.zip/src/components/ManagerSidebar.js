import React from "react";
import {
  FaHome,
  FaListAlt,
  FaSignOutAlt,
  FaProjectDiagram,
} from "react-icons/fa";
import "./ManagerSidebar.css";

const ManagerSidebar = ({ setActiveComponent }) => {
  const handleLogout = () => {
    // Clear the stored active component when logging out
    localStorage.removeItem("managerActiveComponent");
    localStorage.removeItem("token");
    localStorage.removeItem("empId");
    window.location.href = "/login";
  };

  return (
    <div className="manager-sidebar">
      <h2>Manager Dashboard</h2>
      <ul>
        <li onClick={() => setActiveComponent("home")}>
          <FaHome className="icon" /> Dashboard
        </li>
        <li onClick={() => setActiveComponent("view-timesheet")}>
          <FaListAlt className="icon" /> View Timesheet
        </li>
        <li onClick={() => setActiveComponent("add-project")}>
          <FaProjectDiagram className="icon" /> Add Project
        </li>
        <li onClick={handleLogout}>
          <FaSignOutAlt className="icon" /> Logout
        </li>
      </ul>
    </div>
  );
};

export default ManagerSidebar;
