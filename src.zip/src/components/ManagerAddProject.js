import React, { useState, useEffect } from "react";
import axios from "axios";
import "./ManagerAddProject.css";

axios.defaults.baseURL = "http://localhost:8000"; // Backend URL

const ManagerAddProject = () => {
  document.title = "Manager | Add Project";
  const [employees, setEmployees] = useState([]);
  const [filteredEmployees, setFilteredEmployees] = useState([]); // New state for filtered employees
  const [searchTerm, setSearchTerm] = useState(""); // State for search term
  const [selectedEmpId, setSelectedEmpId] = useState("");
  const [projectName, setProjectName] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 7;

  useEffect(() => {
    axios
      .get("/api/employees/")
      .then((response) => {
        setEmployees(response.data);
        setFilteredEmployees(response.data); // Initialize with all employees
      })
      .catch((error) => {
        console.error("Error fetching employees:", error);
      });
  }, []);

  // Filter employees based on search term
  useEffect(() => {
    setFilteredEmployees(
      employees.filter((employee) =>
        employee.emp_id.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
    setCurrentPage(1); // Reset to first page when search term changes
  }, [searchTerm, employees]);

  const handleAddProject = () => {
    axios
      .post("/api/projects/", {
        emp_id: selectedEmpId,
        project_name: projectName,
      })
      .then((response) => {
        alert("Project added successfully!");
        setShowPopup(false);
      })
      .catch((error) => {
        alert("Project added successfully!");
      });
  };

  // Pagination
  const indexOfLastEmployee = currentPage * itemsPerPage;
  const indexOfFirstEmployee = indexOfLastEmployee - itemsPerPage;
  const currentEmployees = filteredEmployees.slice(
    indexOfFirstEmployee,
    indexOfLastEmployee
  );
  const totalPages = Math.ceil(filteredEmployees.length / itemsPerPage);

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <div className="manager-add-project">
      <h2>Add Project</h2>
      <input
        type="text"
        placeholder="Search by Employee ID"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      />
      <div className="pagination-buttons">
        <button onClick={handlePrevPage} disabled={currentPage === 1}>
          {"<"}
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button onClick={handleNextPage} disabled={currentPage === totalPages}>
          {">"}
        </button>
      </div>
      <table>
        <thead>
          <tr>
            <th>Sl.no</th>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Project</th>
          </tr>
        </thead>
        <tbody>
          {currentEmployees.map((employee, index) => (
            <tr key={employee.emp_id}>
              <td>{indexOfFirstEmployee + index + 1}</td>
              <td>{employee.emp_id}</td>
              <td>{employee.emp_name}</td>
              <td>
                <button
                  onClick={() => {
                    setSelectedEmpId(employee.emp_id);
                    setShowPopup(true);
                  }}
                >
                  Add Project
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <h3>Add Project for Employee ID: {selectedEmpId}</h3>
            <form>
              <label>
                Project Name:
                <input
                  type="text"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  required
                />
              </label>
              <button
                type="button"
                className="submit-button"
                onClick={handleAddProject}
              >
                Submit
              </button>
              <button type="button" onClick={() => setShowPopup(false)}>
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManagerAddProject;
