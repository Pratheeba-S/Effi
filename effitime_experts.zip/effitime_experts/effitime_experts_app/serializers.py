from rest_framework import serializers
from .models import Employee, Timesheet, Project
from django.contrib.auth.hashers import make_password

class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = '__all__'

class EmployeeListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = ['emp_id','emp_name']


class TimesheetSerializer(serializers.ModelSerializer):
    emp_id = serializers.CharField(source='emp.emp_id', read_only=True)
    emp_name = serializers.CharField(source='emp.emp_name', read_only=True)
    emp = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), write_only=True)
    project_name = serializers.CharField(read_only=True)

    class Meta:
        model = Timesheet
        fields = ['id', 'emp', 'emp_id', 'emp_name', 'date', 'project_name','project_module', 'start_time', 'end_time', 'comments', 'total_hours', 'lead_approval', 'manager_approval', 'timestamp']


class ProjectSerializer(serializers.ModelSerializer):
    emp_id = serializers.CharField(write_only=True)
    employee_id = serializers.CharField(source='emp.emp_id', read_only=True)  # Add this line

    class Meta:
        model = Project
        fields = ['emp_id', 'employee_id', 'project_name']  # Include both emp_id (write) and employee_id (read)

    def create(self, validated_data):
        emp_id = validated_data.pop('emp_id')
        try:
            employee = Employee.objects.get(emp_id=emp_id)
        except Employee.DoesNotExist:
            raise serializers.ValidationError({"emp_id": "Employee with this ID does not exist."})
        
        project = Project.objects.create(emp=employee, **validated_data)
        return project
